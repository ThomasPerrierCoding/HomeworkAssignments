package edu.ranken.thomasperrier.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    final String NO = "NO ";
    final String NEG = "NEGATIVE ";
    final String IP = "INPUT PROVIDED FOR AMOUNT TO CONVERT";
    final String NC = "NO CONVERTING RATE TO SELF RATE";
    //currency symbols
    final String DOLLAR = "\u0024";
    final String EURO = "\u20ac";
    final String POUND = "\u00a3";
    final String FRANC = "\u20A3";
    final String YEN = "\u00A5";

    //US Dollar to conversions
    final double USD_TO_EEURO = 0.92;
    final double USD_TO_BPOUND = 0.77;
    final double USD_TO_SFRANC = 0.98;
    final double USD_TO_AUSTD = 1.49;
    final double USD_TO_CANAD = 1.33;
    final double USD_TO_NEWZD = 1.55;
    final double USD_TO_JYEN = 109.79;

    //european euro to conversions
    final double EEURO_TO_USD = 1.08;
    final double EEURO_TO_BPOUND = 0.88;
    final double EEURO_TO_SFRANC = 1.06;
    final double EEURO_TO_AUSTD = 1.79;
    final double EEURO_TO_CANAD = 1.54;
    final double EEURO_TO_NEWZD = 1.84;
    final double EEURO_TO_JYEN = 133.40;

    //british pound to conversions
    final double BPOUND_TO_USD = 1.24;
    final double BPOUND_TO_EEURO = 1.31;
    final double BPOUND_TO_SFRANC = 1.19;
    final double BPOUND_TO_AUSTD = 2.02;
    final double BPOUND_TO_CANAD = 1.73;
    final double BPOUND_TO_NEWZD = 2.08;
    final double BPOUND_TO_JYEN = 133.41;

    //Swiss Franc to conversions
    final double SFRANC_TO_USD = 1.02;
    final double SFRANC_TO_EEURO = 0.94;
    final double SFRANC_TO_BPOUND = 0.83;
    final double SFRANC_TO_AUSTD = 1.69;
    final double SFRANC_TO_CANAD = 1.45;
    final double SFRANC_TO_NEWZD = 1.73;
    final double SFRANC_TO_JYEN = 111.53;

    //AUS Dollar to conversions
    final double AUSTD_TO_USD = 0.60;
    final double AUSTD_TO_EEURO = 0.55;
    final double AUSTD_TO_BPOUND = 0.49;
    final double AUSTD_TO_SFRANC = 0.58;
    final double AUSTD_TO_CANAD = 0.85;
    final double AUSTD_TO_NEWZD = 1.02;
    final double AUSTD_TO_JYEN = 65.70;

    //CAN Dollar to conversions
    final double CANAD_TO_USD = 0.70;
    final double CANAD_TO_EEURO = 0.65;
    final double CANAD_TO_BPOUND = 0.57;
    final double CANAD_TO_SFRANC = 0.68;
    final double CANAD_TO_AUSTD = 1.16;
    final double CANAD_TO_NEWZD = 1.19;
    final double CANAD_TO_JYEN = 76.71;

    //NZ Dollar to conversions
    final double NEWZD_TO_USD = 0.58;
    final double NEWZD_TO_EEURO = 0.54;
    final double NEWZD_TO_BPOUND = 0.48;
    final double NEWZD_TO_SFRANC = 0.57;
    final double NEWZD_TO_AUSTD = 0.97;
    final double NEWZD_TO_CANAD = 0.83;
    final double NEWZD_TO_JYEN = 64.07;

    //Japanese Yen to conversions
    final double JYEN_TO_USD = 0.0091;
    final double JYEN_TO_EEURO = 0.0084;
    final double JYEN_TO_BPOUND = 0.0074;
    final double JYEN_TO_SFRANC = 0.0089;
    final double JYEN_TO_AUSTD = 0.0152;
    final double JYEN_TO_CANAD = 0.0130 ;
    final double JYEN_TO_NEWZD = 0.0156;


    EditText editTextAmount;
    Spinner spinnerFrom;
    Spinner spinnerTo;
    Button buttonConvert;
    Toast t;

    boolean keepGoing;
    double inputtedAmount;
    double conversionRate;
    double convertedAmount;
    String convertFrom;
    String convertTo;
    int from;
    int to;
    DecimalFormat df = new DecimalFormat("###,###,##0.00");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);
        editTextAmount = findViewById(R.id.editTextAmount);
        buttonConvert = findViewById(R.id.buttonConvert);

        keepGoing = true;
        inputtedAmount = 0.0;
        conversionRate=0.0;
        convertedAmount=0.0;
        from=-1;
        to=-1;
        convertFrom="";
        convertTo="";

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.currencies_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerFrom.setAdapter(adapter);
        spinnerTo.setAdapter(adapter);

        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keepGoing = checkForNoInput();

                if(keepGoing)
                {
                    doTheConversion();
                }
            }
        });
    }

    private boolean checkForNoInput()
    {
        if(editTextAmount.getText().toString().isEmpty())
        {
            t = Toast.makeText(getApplicationContext(),NO + IP,Toast.LENGTH_LONG);
            t.show();
            return false;
        }
        else
        {
            inputtedAmount = Double.valueOf(editTextAmount.getText().toString());
            if(inputtedAmount<0)
            {
                t = Toast.makeText(getApplicationContext(),NEG + IP,Toast.LENGTH_LONG);
                t.show();
                return false;
            }
            return true;
        }
    }

    private void doTheConversion()
    {
        from = spinnerFrom.getSelectedItemPosition();
        to = spinnerTo.getSelectedItemPosition();

        switch (from)
        {
            case 0:
                convertFrom = " US Dollars";
                switch(to)
                {
                    case 0:
                        conversionRate = 0;

                        t = Toast.makeText(getApplicationContext(),NC,Toast.LENGTH_LONG);
                        t.show();
                        break;
                    case 1:
                        conversionRate = USD_TO_EEURO;
                        convertTo = toType(1);
                        break;
                    case 2:
                        conversionRate = USD_TO_BPOUND;
                        convertTo = toType(2);
                        break;
                    case 3:
                        conversionRate = USD_TO_SFRANC;
                        convertTo = toType(3);
                        break;
                    case 4:
                        conversionRate = USD_TO_AUSTD;
                        convertTo = toType(4);
                        break;
                    case 5:
                        conversionRate = USD_TO_CANAD;
                        convertTo = toType(5);
                        break;
                    case 6:
                        conversionRate = USD_TO_NEWZD;
                        convertTo = toType(1);
                        break;
                    case 7:
                        conversionRate = USD_TO_JYEN;
                        convertTo = toType(7);
                        break;
                }
                break;

            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
        }
        convertedAmount = inputtedAmount * conversionRate;
        t = Toast.makeText(getApplicationContext(),df.format(inputtedAmount).toString() + convertFrom + " = " + df.format(convertedAmount).toString() + convertTo,Toast.LENGTH_LONG);
        t.show();
    }

    private String toType(int fromType)
    {
        String retVal = "";

        switch (fromType)
        {
            case 0:
                retVal = " US Dollars";
                break;
            case 1:
                retVal = " European Euros";
                break;
            case 2:
                retVal = " British Pounds";
                break;
            case 3:
                retVal = " Swiss Francs";
                break;
            case 4:
                retVal = " Australian Dollars";
                break;
            case 5:
                retVal = " Canadian Dollars";
                break;
            case 6:
                retVal = " New Zeleand Dollars";
                break;
            case 7:
                retVal = " Japanese Yen";
                break;
        }
        return retVal;
    }
}
