package edu.ranken.thomasperrier.mockform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    final String NIP = "NO INPUT PROVIDED";

    EditText editTextName;
    EditText editTextAddress;
    EditText editTextCity;
    Spinner spinnerState;
    EditText editTextZipCode;
    RadioGroup radioGroupGender;
    RadioButton radioButtonFemale;
    RadioButton radioButtonMale;
    RadioButton radioButtonPreferNotToAnswer;
    CheckBox checkBoxMorning;
    CheckBox checkBoxAfternoon;
    CheckBox checkBoxEvening;
    Switch switchSettings;
    ImageButton imageButtonToast;

    String name = "";
    String address = "";
    String city = "";
    int zipCode = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = (EditText) findViewById(R.id.editTextName);
        editTextAddress = (EditText) findViewById(R.id.editTextAddress);
        editTextCity = (EditText) findViewById(R.id.editTextCity);
        editTextZipCode = (EditText) findViewById(R.id.editTextZipCode);
        radioGroupGender = (RadioGroup) findViewById(R.id.radioGroupGender);
        radioButtonFemale = (RadioButton) findViewById(R.id.radioButtonFemale);
        radioButtonMale = (RadioButton) findViewById(R.id.radioButtonMale);
        radioButtonPreferNotToAnswer = (RadioButton) findViewById(R.id.radioButtonPreferNotToAnswer);
        checkBoxMorning = (CheckBox) findViewById(R.id.checkBoxMorning);
        checkBoxAfternoon = (CheckBox) findViewById(R.id.checkBoxAfternoon);
        checkBoxEvening = (CheckBox) findViewById(R.id.checkBoxEvening);
        spinnerState = (Spinner) findViewById(R.id.spinnerState);
        switchSettings = (Switch) findViewById(R.id.switchSettings);
        imageButtonToast = (ImageButton) findViewById(R.id.imageButtonToast);

    }

}
